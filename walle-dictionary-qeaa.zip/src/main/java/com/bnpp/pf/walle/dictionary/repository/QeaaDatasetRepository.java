package com.bnpp.pf.walle.dictionary.repository;

import com.bnpp.pf.walle.dictionary.entity.QeaaDatasetEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface QeaaDatasetRepository extends JpaRepository<QeaaDatasetEntity, Long> {}