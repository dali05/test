package com.bnpp.pf.walle.dictionary.service;

import com.bnpp.pf.walle.dictionary.entity.*;
import com.bnpp.pf.walle.dictionary.exception.NotFoundException;
import com.bnpp.pf.walle.dictionary.repository.QeaaDatasetRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class QeaaDatasetService {
    private final QeaaDatasetRepository repo;
    private final QeaaTypeService typeService;
    private final QeaaDataService dataService;

    public QeaaDatasetService(QeaaDatasetRepository repo, QeaaTypeService t, QeaaDataService d) {
        this.repo = repo; this.typeService = t; this.dataService = d;
    }

    public QeaaDatasetEntity create(String name, Long typeId, Long dataId) {
        QeaaTypeEntity type = typeService.get(typeId);
        QeaaDataEntity data = dataService.get(dataId);

        QeaaDatasetEntity e = new QeaaDatasetEntity();
        e.setName(name);
        e.setType(type);
        e.setData(data);
        return repo.save(e);
    }

    public List<QeaaDatasetEntity> list() { return repo.findAll(); }

    public void delete(Long id) {
        if (!repo.existsById(id)) throw new NotFoundException("Dataset not found");
        repo.deleteById(id);
    }
}