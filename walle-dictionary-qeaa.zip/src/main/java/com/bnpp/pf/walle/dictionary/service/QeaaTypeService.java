package com.bnpp.pf.walle.dictionary.service;

import com.bnpp.pf.walle.dictionary.entity.QeaaTypeEntity;
import com.bnpp.pf.walle.dictionary.exception.NotFoundException;
import com.bnpp.pf.walle.dictionary.repository.QeaaTypeRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class QeaaTypeService {
    private final QeaaTypeRepository repo;
    public QeaaTypeService(QeaaTypeRepository repo) { this.repo = repo; }

    public QeaaTypeEntity create(String name) {
        QeaaTypeEntity e = new QeaaTypeEntity();
        e.setName(name);
        return repo.save(e);
    }

    public List<QeaaTypeEntity> list() { return repo.findAll(); }

    public void delete(Long id) {
        if (!repo.existsById(id)) throw new NotFoundException("Type not found");
        repo.deleteById(id);
    }

    public QeaaTypeEntity get(Long id) {
        return repo.findById(id).orElseThrow(() -> new NotFoundException("Type not found"));
    }
}