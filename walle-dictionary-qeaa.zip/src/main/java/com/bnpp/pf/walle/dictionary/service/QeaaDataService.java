package com.bnpp.pf.walle.dictionary.service;

import com.bnpp.pf.walle.dictionary.entity.QeaaDataEntity;
import com.bnpp.pf.walle.dictionary.exception.NotFoundException;
import com.bnpp.pf.walle.dictionary.repository.QeaaDataRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class QeaaDataService {
    private final QeaaDataRepository repo;
    public QeaaDataService(QeaaDataRepository repo) { this.repo = repo; }

    public QeaaDataEntity create(String name) {
        QeaaDataEntity e = new QeaaDataEntity();
        e.setName(name);
        return repo.save(e);
    }

    public List<QeaaDataEntity> list() { return repo.findAll(); }

    public void delete(Long id) {
        if (!repo.existsById(id)) throw new NotFoundException("Data not found");
        repo.deleteById(id);
    }

    public QeaaDataEntity get(Long id) {
        return repo.findById(id).orElseThrow(() -> new NotFoundException("Data not found"));
    }
}