# Tests unitaires QEAA - version UUID

Ces tests supposent que :
- Tous les IDs (DTOs + services + repositories + controllers) sont en `java.util.UUID`
- Tes entités héritent d'une BaseEntity qui contient un champ `id` (UUID).

## Notes
- `EntityTestUtils#setId` pose l'id via reflection (champ `id` sur l'entité OU sur BaseEntity).
- Pour une couverture stricte, tu peux activer JaCoCo (voir snippet).

## Dépendances Maven
- spring-boot-starter-test (JUnit5 + Mockito + MockMvc)
