package com.bnpp.pf.walle.dictionary.exception;

import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.Test;
import org.springframework.core.MethodParameter;
import org.springframework.http.HttpStatus;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class RestExceptionHandlerTest {

    @Test
    void handleNotFound_builds_404() {
        RestExceptionHandler h = new RestExceptionHandler();
        HttpServletRequest req = mock(HttpServletRequest.class);
        when(req.getRequestURI()).thenReturn("/x");

        var resp = h.handleNotFound(new NotFoundException("nope"), req);

        assertEquals(HttpStatus.NOT_FOUND, resp.getStatusCode());
        assertEquals("nope", resp.getBody().message());
        assertEquals("/x", resp.getBody().path());
    }

    @Test
    void handleBadRequest_builds_400() {
        RestExceptionHandler h = new RestExceptionHandler();
        HttpServletRequest req = mock(HttpServletRequest.class);
        when(req.getRequestURI()).thenReturn("/y");

        var resp = h.handleBadRequest(new BadRequestException("bad"), req);

        assertEquals(HttpStatus.BAD_REQUEST, resp.getStatusCode());
        assertEquals("bad", resp.getBody().message());
    }

    @Test
    void handleValidation_builds_400_with_field_message() {
        RestExceptionHandler h = new RestExceptionHandler();
        HttpServletRequest req = mock(HttpServletRequest.class);
        when(req.getRequestURI()).thenReturn("/z");

        var target = new Object();
        var br = new BeanPropertyBindingResult(target, "target");
        br.addError(new FieldError("target", "name", "must not be blank"));

        MethodArgumentNotValidException ex = new MethodArgumentNotValidException((MethodParameter) null, br);

        var resp = h.handleValidation(ex, req);
        assertEquals(HttpStatus.BAD_REQUEST, resp.getStatusCode());
        assertTrue(resp.getBody().message().contains("name"));
    }
}
