package com.bnpp.pf.walle.dictionary.util;

import java.lang.reflect.Field;
import java.util.UUID;

public final class EntityTestUtils {
    private EntityTestUtils() {}

    public static void setId(Object entity, UUID id) {
        Class<?> c = entity.getClass();
        while (c != null) {
            try {
                Field f = c.getDeclaredField("id");
                f.setAccessible(true);
                f.set(entity, id);
                return;
            } catch (NoSuchFieldException e) {
                c = c.getSuperclass();
            } catch (IllegalAccessException e) {
                throw new RuntimeException(e);
            }
        }
        throw new IllegalStateException("No field named 'id' found on " + entity.getClass());
    }
}
