package com.bnpp.pf.walle.dictionary.service;

import com.bnpp.pf.walle.dictionary.dto.QeaaTypeDtos;
import com.bnpp.pf.walle.dictionary.entity.QeaaTypeEntity;
import com.bnpp.pf.walle.dictionary.exception.NotFoundException;
import com.bnpp.pf.walle.dictionary.repository.QeaaTypeRepository;
import com.bnpp.pf.walle.dictionary.util.EntityTestUtils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class QeaaTypeServiceTest {

    @Mock QeaaTypeRepository repo;
    @InjectMocks QeaaTypeService service;

    @Test
    void create_saves_and_returns_dto() {
        UUID id = UUID.fromString("11111111-1111-1111-1111-111111111111");

        when(repo.save(any())).thenAnswer(inv -> {
            QeaaTypeEntity e = inv.getArgument(0);
            var persisted = new QeaaTypeEntity();
            persisted.setName(e.getName());
            EntityTestUtils.setId(persisted, id);
            return persisted;
        });

        var dto = service.create(new QeaaTypeDtos.CreateOrUpdateRequest("TYPE_A"));

        assertEquals(id, dto.id());
        assertEquals("TYPE_A", dto.name());

        ArgumentCaptor<QeaaTypeEntity> captor = ArgumentCaptor.forClass(QeaaTypeEntity.class);
        verify(repo).save(captor.capture());
        assertEquals("TYPE_A", captor.getValue().getName());
    }

    @Test
    void list_maps_entities() {
        var e1 = new QeaaTypeEntity(); e1.setName("T1");
        var e2 = new QeaaTypeEntity(); e2.setName("T2");
        EntityTestUtils.setId(e1, UUID.fromString("aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa"));
        EntityTestUtils.setId(e2, UUID.fromString("bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb"));

        when(repo.findAll()).thenReturn(List.of(e1, e2));

        var out = service.list();

        assertEquals(2, out.size());
        assertEquals("T1", out.get(0).name());
        assertEquals("T2", out.get(1).name());
    }

    @Test
    void update_updates_name() {
        UUID id = UUID.fromString("22222222-2222-2222-2222-222222222222");
        var e = new QeaaTypeEntity();
        EntityTestUtils.setId(e, id);
        e.setName("OLD");

        when(repo.findById(id)).thenReturn(Optional.of(e));

        var out = service.update(id, new QeaaTypeDtos.CreateOrUpdateRequest("NEW"));

        assertEquals(id, out.id());
        assertEquals("NEW", out.name());
        assertEquals("NEW", e.getName());
    }

    @Test
    void update_throws_when_missing() {
        UUID id = UUID.fromString("33333333-3333-3333-3333-333333333333");
        when(repo.findById(id)).thenReturn(Optional.empty());
        assertThrows(NotFoundException.class,
                () -> service.update(id, new QeaaTypeDtos.CreateOrUpdateRequest("X")));
    }

    @Test
    void delete_throws_when_missing() {
        UUID id = UUID.fromString("44444444-4444-4444-4444-444444444444");
        when(repo.existsById(id)).thenReturn(false);
        assertThrows(NotFoundException.class, () -> service.delete(id));
    }

    @Test
    void delete_deletes_when_exists() {
        UUID id = UUID.fromString("55555555-5555-5555-5555-555555555555");
        when(repo.existsById(id)).thenReturn(true);
        service.delete(id);
        verify(repo).deleteById(id);
    }

    @Test
    void getEntity_returns_entity() {
        UUID id = UUID.fromString("66666666-6666-6666-6666-666666666666");
        var e = new QeaaTypeEntity();
        EntityTestUtils.setId(e, id);
        when(repo.findById(id)).thenReturn(Optional.of(e));
        assertSame(e, service.getEntity(id));
    }

    @Test
    void getEntity_throws_when_missing() {
        UUID id = UUID.fromString("77777777-7777-7777-7777-777777777777");
        when(repo.findById(id)).thenReturn(Optional.empty());
        assertThrows(NotFoundException.class, () -> service.getEntity(id));
    }
}
