package com.bnpp.pf.walle.dictionary.service;

import com.bnpp.pf.walle.dictionary.dto.QeaaDataDtos;
import com.bnpp.pf.walle.dictionary.entity.QeaaDataEntity;
import com.bnpp.pf.walle.dictionary.exception.NotFoundException;
import com.bnpp.pf.walle.dictionary.repository.QeaaDataRepository;
import com.bnpp.pf.walle.dictionary.util.EntityTestUtils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class QeaaDataServiceTest {

    @Mock QeaaDataRepository repo;
    @InjectMocks QeaaDataService service;

    @Test
    void create_saves_and_returns_dto() {
        UUID id = UUID.fromString("88888888-8888-8888-8888-888888888888");

        when(repo.save(any())).thenAnswer(inv -> {
            QeaaDataEntity e = inv.getArgument(0);
            var persisted = new QeaaDataEntity();
            persisted.setName(e.getName());
            EntityTestUtils.setId(persisted, id);
            return persisted;
        });

        var dto = service.create(new QeaaDataDtos.CreateOrUpdateRequest("DATA_A"));
        assertEquals(id, dto.id());
        assertEquals("DATA_A", dto.name());
    }

    @Test
    void list_maps_entities() {
        var e1 = new QeaaDataEntity(); e1.setName("D1");
        var e2 = new QeaaDataEntity(); e2.setName("D2");
        EntityTestUtils.setId(e1, UUID.fromString("99999999-9999-9999-9999-999999999999"));
        EntityTestUtils.setId(e2, UUID.fromString("aaaaaaaa-0000-0000-0000-000000000000"));
        when(repo.findAll()).thenReturn(List.of(e1, e2));

        var out = service.list();
        assertEquals(2, out.size());
        assertEquals("D2", out.get(1).name());
    }

    @Test
    void update_updates_name() {
        UUID id = UUID.fromString("bbbbbbbb-0000-0000-0000-000000000000");
        var e = new QeaaDataEntity(); EntityTestUtils.setId(e, id); e.setName("OLD");
        when(repo.findById(id)).thenReturn(Optional.of(e));

        var out = service.update(id, new QeaaDataDtos.CreateOrUpdateRequest("NEW"));
        assertEquals(id, out.id());
        assertEquals("NEW", out.name());
        assertEquals("NEW", e.getName());
    }

    @Test
    void update_throws_when_missing() {
        UUID id = UUID.fromString("cccccccc-0000-0000-0000-000000000000");
        when(repo.findById(id)).thenReturn(Optional.empty());
        assertThrows(NotFoundException.class,
                () -> service.update(id, new QeaaDataDtos.CreateOrUpdateRequest("X")));
    }

    @Test
    void delete_throws_when_missing() {
        UUID id = UUID.fromString("dddddddd-0000-0000-0000-000000000000");
        when(repo.existsById(id)).thenReturn(false);
        assertThrows(NotFoundException.class, () -> service.delete(id));
    }

    @Test
    void delete_deletes_when_exists() {
        UUID id = UUID.fromString("eeeeeeee-0000-0000-0000-000000000000");
        when(repo.existsById(id)).thenReturn(true);
        service.delete(id);
        verify(repo).deleteById(id);
    }

    @Test
    void getEntity_returns_entity() {
        UUID id = UUID.fromString("ffffffff-0000-0000-0000-000000000000");
        var e = new QeaaDataEntity(); EntityTestUtils.setId(e, id);
        when(repo.findById(id)).thenReturn(Optional.of(e));
        assertSame(e, service.getEntity(id));
    }

    @Test
    void getEntity_throws_when_missing() {
        UUID id = UUID.fromString("12121212-1212-1212-1212-121212121212");
        when(repo.findById(id)).thenReturn(Optional.empty());
        assertThrows(NotFoundException.class, () -> service.getEntity(id));
    }
}
