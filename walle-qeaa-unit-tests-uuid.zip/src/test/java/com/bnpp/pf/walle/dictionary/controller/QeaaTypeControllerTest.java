package com.bnpp.pf.walle.dictionary.controller;

import com.bnpp.pf.walle.dictionary.dto.QeaaTypeDtos;
import com.bnpp.pf.walle.dictionary.service.QeaaTypeService;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.List;
import java.util.UUID;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

class QeaaTypeControllerTest {

    @Test
    void crud_flow() throws Exception {
        QeaaTypeService service = mock(QeaaTypeService.class);
        QeaaTypeController controller = new QeaaTypeController(service);
        MockMvc mvc = MockMvcBuilders.standaloneSetup(controller).build();

        UUID id = UUID.fromString("11111111-1111-1111-1111-111111111111");

        when(service.create(any())).thenReturn(new QeaaTypeDtos.Response(id, "T1"));
        when(service.list()).thenReturn(List.of(new QeaaTypeDtos.Response(id, "T1")));
        when(service.update(eq(id), any())).thenReturn(new QeaaTypeDtos.Response(id, "T2"));

        mvc.perform(post("/api/v1/dictionary/qeaa/types")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"name\":\"T1\"}"))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(id.toString()))
                .andExpect(jsonPath("$.name").value("T1"));

        mvc.perform(get("/api/v1/dictionary/qeaa/types"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].name").value("T1"));

        mvc.perform(put("/api/v1/dictionary/qeaa/types/" + id)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"name\":\"T2\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("T2"));

        mvc.perform(delete("/api/v1/dictionary/qeaa/types/" + id))
                .andExpect(status().isNoContent());

        verify(service).delete(id);
    }
}
