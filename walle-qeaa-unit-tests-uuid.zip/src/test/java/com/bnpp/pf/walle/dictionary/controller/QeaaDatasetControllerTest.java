package com.bnpp.pf.walle.dictionary.controller;

import com.bnpp.pf.walle.dictionary.dto.QeaaDatasetDtos;
import com.bnpp.pf.walle.dictionary.service.QeaaDatasetService;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.List;
import java.util.UUID;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

class QeaaDatasetControllerTest {

    @Test
    void crud_flow() throws Exception {
        QeaaDatasetService service = mock(QeaaDatasetService.class);
        QeaaDatasetController controller = new QeaaDatasetController(service);
        MockMvc mvc = MockMvcBuilders.standaloneSetup(controller).build();

        UUID datasetId = UUID.fromString("33333333-3333-3333-3333-333333333333");
        UUID typeId = UUID.fromString("44444444-4444-4444-4444-444444444444");
        UUID dataId = UUID.fromString("55555555-5555-5555-5555-555555555555");

        when(service.create(any())).thenReturn(new QeaaDatasetDtos.Response(datasetId, "DS1", typeId, "T", dataId, "D"));
        when(service.list()).thenReturn(List.of(new QeaaDatasetDtos.Response(datasetId, "DS1", typeId, "T", dataId, "D")));
        when(service.update(eq(datasetId), any())).thenReturn(new QeaaDatasetDtos.Response(datasetId, "DS2", typeId, "T", dataId, "D"));

        mvc.perform(post("/api/v1/dictionary/qeaa/datasets")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"name\":\"DS1\",\"typeId\":\"" + typeId + "\",\"dataId\":\"" + dataId + "\"}"))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(datasetId.toString()))
                .andExpect(jsonPath("$.name").value("DS1"))
                .andExpect(jsonPath("$.typeId").value(typeId.toString()))
                .andExpect(jsonPath("$.dataId").value(dataId.toString()));

        mvc.perform(get("/api/v1/dictionary/qeaa/datasets"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].name").value("DS1"));

        mvc.perform(put("/api/v1/dictionary/qeaa/datasets/" + datasetId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"name\":\"DS2\",\"typeId\":\"" + typeId + "\",\"dataId\":\"" + dataId + "\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("DS2"));

        mvc.perform(delete("/api/v1/dictionary/qeaa/datasets/" + datasetId))
                .andExpect(status().isNoContent());

        verify(service).delete(datasetId);
    }
}
