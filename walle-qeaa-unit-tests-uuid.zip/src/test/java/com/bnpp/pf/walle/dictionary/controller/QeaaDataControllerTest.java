package com.bnpp.pf.walle.dictionary.controller;

import com.bnpp.pf.walle.dictionary.dto.QeaaDataDtos;
import com.bnpp.pf.walle.dictionary.service.QeaaDataService;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.List;
import java.util.UUID;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

class QeaaDataControllerTest {

    @Test
    void crud_flow() throws Exception {
        QeaaDataService service = mock(QeaaDataService.class);
        QeaaDataController controller = new QeaaDataController(service);
        MockMvc mvc = MockMvcBuilders.standaloneSetup(controller).build();

        UUID id = UUID.fromString("22222222-2222-2222-2222-222222222222");

        when(service.create(any())).thenReturn(new QeaaDataDtos.Response(id, "D1"));
        when(service.list()).thenReturn(List.of(new QeaaDataDtos.Response(id, "D1")));
        when(service.update(eq(id), any())).thenReturn(new QeaaDataDtos.Response(id, "D2"));

        mvc.perform(post("/api/v1/dictionary/qeaa/data")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"name\":\"D1\"}"))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(id.toString()))
                .andExpect(jsonPath("$.name").value("D1"));

        mvc.perform(get("/api/v1/dictionary/qeaa/data"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].name").value("D1"));

        mvc.perform(put("/api/v1/dictionary/qeaa/data/" + id)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"name\":\"D2\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("D2"));

        mvc.perform(delete("/api/v1/dictionary/qeaa/data/" + id))
                .andExpect(status().isNoContent());

        verify(service).delete(id);
    }
}
