package com.bnpp.pf.walle.dictionary.service;

import com.bnpp.pf.walle.dictionary.dto.QeaaDatasetDtos;
import com.bnpp.pf.walle.dictionary.entity.QeaaDataEntity;
import com.bnpp.pf.walle.dictionary.entity.QeaaDatasetEntity;
import com.bnpp.pf.walle.dictionary.entity.QeaaTypeEntity;
import com.bnpp.pf.walle.dictionary.exception.NotFoundException;
import com.bnpp.pf.walle.dictionary.repository.QeaaDatasetRepository;
import com.bnpp.pf.walle.dictionary.util.EntityTestUtils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class QeaaDatasetServiceTest {

    @Mock QeaaDatasetRepository repo;
    @Mock QeaaTypeService typeService;
    @Mock QeaaDataService dataService;

    @InjectMocks QeaaDatasetService service;

    @Test
    void create_requires_type_and_data_and_returns_dto() {
        UUID typeId = UUID.fromString("10101010-1010-1010-1010-101010101010");
        UUID dataId = UUID.fromString("20202020-2020-2020-2020-202020202020");
        UUID dsId   = UUID.fromString("30303030-3030-3030-3030-303030303030");

        var type = new QeaaTypeEntity(); type.setName("T"); EntityTestUtils.setId(type, typeId);
        var data = new QeaaDataEntity(); data.setName("D"); EntityTestUtils.setId(data, dataId);

        when(typeService.getEntity(typeId)).thenReturn(type);
        when(dataService.getEntity(dataId)).thenReturn(data);

        when(repo.save(any())).thenAnswer(inv -> {
            QeaaDatasetEntity e = inv.getArgument(0);
            EntityTestUtils.setId(e, dsId);
            return e;
        });

        var out = service.create(new QeaaDatasetDtos.CreateOrUpdateRequest("DS", typeId, dataId));

        assertEquals(dsId, out.id());
        assertEquals("DS", out.name());
        assertEquals(typeId, out.typeId());
        assertEquals("T", out.typeName());
        assertEquals(dataId, out.dataId());
        assertEquals("D", out.dataName());
    }

    @Test
    void create_propagates_not_found_from_dependencies() {
        UUID typeId = UUID.fromString("40404040-4040-4040-4040-404040404040");
        UUID dataId = UUID.fromString("50505050-5050-5050-5050-505050505050");

        when(typeService.getEntity(typeId)).thenThrow(new NotFoundException("QEAAType not found: " + typeId));
        assertThrows(NotFoundException.class,
                () -> service.create(new QeaaDatasetDtos.CreateOrUpdateRequest("DS", typeId, dataId)));
        verifyNoInteractions(repo);
    }

    @Test
    void list_maps_entities() {
        UUID typeId = UUID.fromString("60606060-6060-6060-6060-606060606060");
        UUID dataId = UUID.fromString("70707070-7070-7070-7070-707070707070");
        UUID dsId   = UUID.fromString("80808080-8080-8080-8080-808080808080");

        var type = new QeaaTypeEntity(); type.setName("T"); EntityTestUtils.setId(type, typeId);
        var data = new QeaaDataEntity(); data.setName("D"); EntityTestUtils.setId(data, dataId);

        var ds = new QeaaDatasetEntity();
        EntityTestUtils.setId(ds, dsId);
        ds.setName("DS");
        ds.setType(type);
        ds.setData(data);

        when(repo.findAll()).thenReturn(List.of(ds));

        var out = service.list();
        assertEquals(1, out.size());
        assertEquals("DS", out.get(0).name());
        assertEquals("T", out.get(0).typeName());
        assertEquals("D", out.get(0).dataName());
    }

    @Test
    void update_updates_fields() {
        UUID existingId = UUID.fromString("90909090-9090-9090-9090-909090909090");
        UUID typeId = UUID.fromString("a0a0a0a0-a0a0-a0a0-a0a0-a0a0a0a0a0a0");
        UUID dataId = UUID.fromString("b0b0b0b0-b0b0-b0b0-b0b0-b0b0b0b0b0b0");

        var type = new QeaaTypeEntity(); type.setName("T2"); EntityTestUtils.setId(type, typeId);
        var data = new QeaaDataEntity(); data.setName("D2"); EntityTestUtils.setId(data, dataId);

        when(typeService.getEntity(typeId)).thenReturn(type);
        when(dataService.getEntity(dataId)).thenReturn(data);

        var existing = new QeaaDatasetEntity();
        EntityTestUtils.setId(existing, existingId);
        existing.setName("OLD");

        when(repo.findById(existingId)).thenReturn(Optional.of(existing));

        var out = service.update(existingId, new QeaaDatasetDtos.CreateOrUpdateRequest("NEW", typeId, dataId));

        assertEquals(existingId, out.id());
        assertEquals("NEW", out.name());
        assertEquals("T2", out.typeName());
        assertEquals("D2", out.dataName());
        assertEquals("NEW", existing.getName());
        assertSame(type, existing.getType());
        assertSame(data, existing.getData());
    }

    @Test
    void update_throws_when_missing_dataset() {
        UUID id = UUID.fromString("c0c0c0c0-c0c0-c0c0-c0c0-c0c0c0c0c0c0");
        UUID typeId = UUID.fromString("d0d0d0d0-d0d0-d0d0-d0d0-d0d0d0d0d0d0");
        UUID dataId = UUID.fromString("e0e0e0e0-e0e0-e0e0-e0e0-e0e0e0e0e0e0");

        when(repo.findById(id)).thenReturn(Optional.empty());
        assertThrows(NotFoundException.class,
                () -> service.update(id, new QeaaDatasetDtos.CreateOrUpdateRequest("NEW", typeId, dataId)));
        verifyNoInteractions(typeService);
        verifyNoInteractions(dataService);
    }

    @Test
    void delete_throws_when_missing() {
        UUID id = UUID.fromString("f0f0f0f0-f0f0-f0f0-f0f0-f0f0f0f0f0f0");
        when(repo.existsById(id)).thenReturn(false);
        assertThrows(NotFoundException.class, () -> service.delete(id));
    }

    @Test
    void delete_deletes_when_exists() {
        UUID id = UUID.fromString("01010101-0202-0303-0404-050505050505");
        when(repo.existsById(id)).thenReturn(true);
        service.delete(id);
        verify(repo).deleteById(id);
    }
}
