# QEAA Dictionary CRUD (Walle)

Contenu :
- Entities JPA : QeaaTypeEntity, QeaaDataEntity, QeaaDatasetEntity
- Repositories Spring Data JPA
- Services (CRUD + règle: dataset => typeId & dataId doivent exister)
- Controllers REST
- Exceptions + handler
- Liquibase YAML (master + qeaa)

Endpoints:
- /api/v1/dictionary/qeaa/types
- /api/v1/dictionary/qeaa/data
- /api/v1/dictionary/qeaa/datasets
