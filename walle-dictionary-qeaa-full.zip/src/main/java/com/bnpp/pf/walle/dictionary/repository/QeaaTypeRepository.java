package com.bnpp.pf.walle.dictionary.repository;

import com.bnpp.pf.walle.dictionary.entity.QeaaTypeEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface QeaaTypeRepository extends JpaRepository<QeaaTypeEntity, Long> {
}
