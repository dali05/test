package com.bnpp.pf.walle.dictionary.controller;

import com.bnpp.pf.walle.dictionary.dto.QeaaTypeDtos;
import com.bnpp.pf.walle.dictionary.service.QeaaTypeService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/dictionary/qeaa/types")
public class QeaaTypeController {

    private final QeaaTypeService service;

    public QeaaTypeController(QeaaTypeService service) {
        this.service = service;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public QeaaTypeDtos.Response create(@RequestBody @Valid QeaaTypeDtos.CreateOrUpdateRequest req) {
        return service.create(req);
    }

    @GetMapping
    public List<QeaaTypeDtos.Response> list() {
        return service.list();
    }

    @PutMapping("/{id}")
    public QeaaTypeDtos.Response update(@PathVariable Long id, @RequestBody @Valid QeaaTypeDtos.CreateOrUpdateRequest req) {
        return service.update(id, req);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}
