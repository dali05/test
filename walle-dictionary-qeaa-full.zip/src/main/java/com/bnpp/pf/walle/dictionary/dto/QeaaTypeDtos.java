package com.bnpp.pf.walle.dictionary.dto;

import jakarta.validation.constraints.NotBlank;

public final class QeaaTypeDtos {
    private QeaaTypeDtos() {}

    public record CreateOrUpdateRequest(@NotBlank String name) {}
    public record Response(Long id, String name) {}
}
