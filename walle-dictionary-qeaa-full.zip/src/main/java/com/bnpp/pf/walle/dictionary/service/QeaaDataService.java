package com.bnpp.pf.walle.dictionary.service;

import com.bnpp.pf.walle.dictionary.dto.QeaaDataDtos;
import com.bnpp.pf.walle.dictionary.entity.QeaaDataEntity;
import com.bnpp.pf.walle.dictionary.exception.NotFoundException;
import com.bnpp.pf.walle.dictionary.repository.QeaaDataRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class QeaaDataService {

    private final QeaaDataRepository repo;

    public QeaaDataService(QeaaDataRepository repo) {
        this.repo = repo;
    }

    public QeaaDataDtos.Response create(QeaaDataDtos.CreateOrUpdateRequest req) {
        QeaaDataEntity e = new QeaaDataEntity();
        e.setName(req.name());
        e = repo.save(e);
        return new QeaaDataDtos.Response(e.getId(), e.getName());
    }

    @Transactional(readOnly = true)
    public List<QeaaDataDtos.Response> list() {
        return repo.findAll().stream()
                .map(e -> new QeaaDataDtos.Response(e.getId(), e.getName()))
                .toList();
    }

    public QeaaDataDtos.Response update(Long id, QeaaDataDtos.CreateOrUpdateRequest req) {
        QeaaDataEntity e = repo.findById(id)
                .orElseThrow(() -> new NotFoundException("QEAData not found: " + id));
        e.setName(req.name());
        return new QeaaDataDtos.Response(e.getId(), e.getName());
    }

    public void delete(Long id) {
        if (!repo.existsById(id)) {
            throw new NotFoundException("QEAData not found: " + id);
        }
        repo.deleteById(id);
    }

    @Transactional(readOnly = true)
    public QeaaDataEntity getEntity(Long id) {
        return repo.findById(id).orElseThrow(() -> new NotFoundException("QEAData not found: " + id));
    }
}
