package com.bnpp.pf.walle.dictionary.service;

import com.bnpp.pf.walle.dictionary.dto.QeaaTypeDtos;
import com.bnpp.pf.walle.dictionary.entity.QeaaTypeEntity;
import com.bnpp.pf.walle.dictionary.exception.NotFoundException;
import com.bnpp.pf.walle.dictionary.repository.QeaaTypeRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class QeaaTypeService {

    private final QeaaTypeRepository repo;

    public QeaaTypeService(QeaaTypeRepository repo) {
        this.repo = repo;
    }

    public QeaaTypeDtos.Response create(QeaaTypeDtos.CreateOrUpdateRequest req) {
        QeaaTypeEntity e = new QeaaTypeEntity();
        e.setName(req.name());
        e = repo.save(e);
        return new QeaaTypeDtos.Response(e.getId(), e.getName());
    }

    @Transactional(readOnly = true)
    public List<QeaaTypeDtos.Response> list() {
        return repo.findAll().stream()
                .map(e -> new QeaaTypeDtos.Response(e.getId(), e.getName()))
                .toList();
    }

    public QeaaTypeDtos.Response update(Long id, QeaaTypeDtos.CreateOrUpdateRequest req) {
        QeaaTypeEntity e = repo.findById(id)
                .orElseThrow(() -> new NotFoundException("QEAAType not found: " + id));
        e.setName(req.name());
        return new QeaaTypeDtos.Response(e.getId(), e.getName());
    }

    public void delete(Long id) {
        if (!repo.existsById(id)) {
            throw new NotFoundException("QEAAType not found: " + id);
        }
        repo.deleteById(id);
    }

    @Transactional(readOnly = true)
    public QeaaTypeEntity getEntity(Long id) {
        return repo.findById(id).orElseThrow(() -> new NotFoundException("QEAAType not found: " + id));
    }
}
