package com.bnpp.pf.walle.dictionary.controller;

import com.bnpp.pf.walle.dictionary.dto.QeaaDatasetDtos;
import com.bnpp.pf.walle.dictionary.service.QeaaDatasetService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/dictionary/qeaa/datasets")
public class QeaaDatasetController {

    private final QeaaDatasetService service;

    public QeaaDatasetController(QeaaDatasetService service) {
        this.service = service;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public QeaaDatasetDtos.Response create(@RequestBody @Valid QeaaDatasetDtos.CreateOrUpdateRequest req) {
        return service.create(req);
    }

    @GetMapping
    public List<QeaaDatasetDtos.Response> list() {
        return service.list();
    }

    @PutMapping("/{id}")
    public QeaaDatasetDtos.Response update(@PathVariable Long id, @RequestBody @Valid QeaaDatasetDtos.CreateOrUpdateRequest req) {
        return service.update(id, req);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}
