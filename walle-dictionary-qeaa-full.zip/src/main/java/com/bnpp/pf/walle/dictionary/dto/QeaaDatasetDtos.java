package com.bnpp.pf.walle.dictionary.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public final class QeaaDatasetDtos {
    private QeaaDatasetDtos() {}

    public record CreateOrUpdateRequest(
            @NotBlank String name,
            @NotNull Long typeId,
            @NotNull Long dataId
    ) {}

    public record Response(
            Long id,
            String name,
            Long typeId,
            String typeName,
            Long dataId,
            String dataName
    ) {}
}
