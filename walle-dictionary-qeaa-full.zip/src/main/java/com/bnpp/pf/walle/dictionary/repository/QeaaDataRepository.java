package com.bnpp.pf.walle.dictionary.repository;

import com.bnpp.pf.walle.dictionary.entity.QeaaDataEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface QeaaDataRepository extends JpaRepository<QeaaDataEntity, Long> {
}
