package com.bnpp.pf.walle.dictionary.service;

import com.bnpp.pf.walle.dictionary.dto.QeaaDatasetDtos;
import com.bnpp.pf.walle.dictionary.entity.QeaaDatasetEntity;
import com.bnpp.pf.walle.dictionary.entity.QeaaDataEntity;
import com.bnpp.pf.walle.dictionary.entity.QeaaTypeEntity;
import com.bnpp.pf.walle.dictionary.exception.NotFoundException;
import com.bnpp.pf.walle.dictionary.repository.QeaaDatasetRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class QeaaDatasetService {

    private final QeaaDatasetRepository repo;
    private final QeaaTypeService typeService;
    private final QeaaDataService dataService;

    public QeaaDatasetService(QeaaDatasetRepository repo, QeaaTypeService typeService, QeaaDataService dataService) {
        this.repo = repo;
        this.typeService = typeService;
        this.dataService = dataService;
    }

    public QeaaDatasetDtos.Response create(QeaaDatasetDtos.CreateOrUpdateRequest req) {
        QeaaTypeEntity type = typeService.getEntity(req.typeId());
        QeaaDataEntity data = dataService.getEntity(req.dataId());

        QeaaDatasetEntity e = new QeaaDatasetEntity();
        e.setName(req.name());
        e.setType(type);
        e.setData(data);

        e = repo.save(e);
        return toDto(e);
    }

    @Transactional(readOnly = true)
    public List<QeaaDatasetDtos.Response> list() {
        return repo.findAll().stream().map(this::toDto).toList();
    }

    public QeaaDatasetDtos.Response update(Long id, QeaaDatasetDtos.CreateOrUpdateRequest req) {
        QeaaDatasetEntity e = repo.findById(id)
                .orElseThrow(() -> new NotFoundException("QEAADataset not found: " + id));

        QeaaTypeEntity type = typeService.getEntity(req.typeId());
        QeaaDataEntity data = dataService.getEntity(req.dataId());

        e.setName(req.name());
        e.setType(type);
        e.setData(data);

        return toDto(e);
    }

    public void delete(Long id) {
        if (!repo.existsById(id)) {
            throw new NotFoundException("QEAADataset not found: " + id);
        }
        repo.deleteById(id);
    }

    private QeaaDatasetDtos.Response toDto(QeaaDatasetEntity e) {
        return new QeaaDatasetDtos.Response(
                e.getId(),
                e.getName(),
                e.getType().getId(),
                e.getType().getName(),
                e.getData().getId(),
                e.getData().getName()
        );
    }
}
