package com.bnpp.pf.walle.dictionary.controller;

import com.bnpp.pf.walle.dictionary.dto.QeaaDataDtos;
import com.bnpp.pf.walle.dictionary.service.QeaaDataService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/dictionary/qeaa/data")
public class QeaaDataController {

    private final QeaaDataService service;

    public QeaaDataController(QeaaDataService service) {
        this.service = service;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public QeaaDataDtos.Response create(@RequestBody @Valid QeaaDataDtos.CreateOrUpdateRequest req) {
        return service.create(req);
    }

    @GetMapping
    public List<QeaaDataDtos.Response> list() {
        return service.list();
    }

    @PutMapping("/{id}")
    public QeaaDataDtos.Response update(@PathVariable Long id, @RequestBody @Valid QeaaDataDtos.CreateOrUpdateRequest req) {
        return service.update(id, req);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}
