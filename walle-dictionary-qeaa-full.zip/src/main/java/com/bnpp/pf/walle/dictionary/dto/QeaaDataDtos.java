package com.bnpp.pf.walle.dictionary.dto;

import jakarta.validation.constraints.NotBlank;

public final class QeaaDataDtos {
    private QeaaDataDtos() {}

    public record CreateOrUpdateRequest(@NotBlank String name) {}
    public record Response(Long id, String name) {}
}
