package com.bnpp.pf.walle.dictionary.service;

import com.bnpp.pf.walle.dictionary.dto.QeaaTypeDtos;
import com.bnpp.pf.walle.dictionary.entity.QeaaTypeEntity;
import com.bnpp.pf.walle.dictionary.exception.NotFoundException;
import com.bnpp.pf.walle.dictionary.repository.QeaaTypeRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class QeaaTypeServiceTest {

    @Mock
    QeaaTypeRepository repo;

    @InjectMocks
    QeaaTypeService service;

    @Test
    void create_saves_and_returns_dto() {
        when(repo.save(any())).thenAnswer(inv -> {
            QeaaTypeEntity e = inv.getArgument(0);
            var persisted = new QeaaTypeEntity();
            persisted.setName(e.getName());
            setId(persisted, 10L);
            return persisted;
        });

        var dto = service.create(new QeaaTypeDtos.CreateOrUpdateRequest("TYPE_A"));

        assertEquals(10L, dto.id());
        assertEquals("TYPE_A", dto.name());

        ArgumentCaptor<QeaaTypeEntity> captor = ArgumentCaptor.forClass(QeaaTypeEntity.class);
        verify(repo).save(captor.capture());
        assertEquals("TYPE_A", captor.getValue().getName());
    }

    @Test
    void list_maps_entities() {
        QeaaTypeEntity e1 = new QeaaTypeEntity();
        e1.setName("T1");
        QeaaTypeEntity e2 = new QeaaTypeEntity();
        e2.setName("T2");
        setId(e1, 1L);
        setId(e2, 2L);

        when(repo.findAll()).thenReturn(List.of(e1, e2));

        var out = service.list();

        assertEquals(2, out.size());
        assertEquals(1L, out.get(0).id());
        assertEquals("T1", out.get(0).name());
        assertEquals(2L, out.get(1).id());
        assertEquals("T2", out.get(1).name());
    }

    @Test
    void update_updates_name() {
        QeaaTypeEntity e = new QeaaTypeEntity();
        setId(e, 7L);
        e.setName("OLD");

        when(repo.findById(7L)).thenReturn(Optional.of(e));

        var out = service.update(7L, new QeaaTypeDtos.CreateOrUpdateRequest("NEW"));

        assertEquals(7L, out.id());
        assertEquals("NEW", out.name());
        assertEquals("NEW", e.getName());
    }

    @Test
    void update_throws_when_missing() {
        when(repo.findById(99L)).thenReturn(Optional.empty());
        assertThrows(NotFoundException.class,
                () -> service.update(99L, new QeaaTypeDtos.CreateOrUpdateRequest("X")));
    }

    @Test
    void delete_throws_when_missing() {
        when(repo.existsById(5L)).thenReturn(false);
        assertThrows(NotFoundException.class, () -> service.delete(5L));
    }

    @Test
    void delete_deletes_when_exists() {
        when(repo.existsById(5L)).thenReturn(true);
        service.delete(5L);
        verify(repo).deleteById(5L);
    }

    @Test
    void getEntity_returns_entity() {
        QeaaTypeEntity e = new QeaaTypeEntity();
        setId(e, 3L);
        when(repo.findById(3L)).thenReturn(Optional.of(e));
        assertSame(e, service.getEntity(3L));
    }

    @Test
    void getEntity_throws_when_missing() {
        when(repo.findById(3L)).thenReturn(Optional.empty());
        assertThrows(NotFoundException.class, () -> service.getEntity(3L));
    }

    private static void setId(Object obj, Long id) {
        try {
            var f = obj.getClass().getDeclaredField("id");
            f.setAccessible(true);
            f.set(obj, id);
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }
}
