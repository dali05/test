package com.bnpp.pf.walle.dictionary.entity;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class EntitiesSmokeTest {

    @Test
    void qeaaType_getters_setters() {
        QeaaTypeEntity e = new QeaaTypeEntity();
        e.setName("X");
        assertEquals("X", e.getName());
    }

    @Test
    void qeaaData_getters_setters() {
        QeaaDataEntity e = new QeaaDataEntity();
        e.setName("Y");
        assertEquals("Y", e.getName());
    }

    @Test
    void qeaaDataset_getters_setters() {
        QeaaDatasetEntity ds = new QeaaDatasetEntity();
        ds.setName("DS");
        QeaaTypeEntity t = new QeaaTypeEntity(); t.setName("T");
        QeaaDataEntity d = new QeaaDataEntity(); d.setName("D");

        ds.setType(t);
        ds.setData(d);

        assertEquals("DS", ds.getName());
        assertSame(t, ds.getType());
        assertSame(d, ds.getData());
    }
}
