package com.bnpp.pf.walle.dictionary.controller;

import com.bnpp.pf.walle.dictionary.dto.QeaaDataDtos;
import com.bnpp.pf.walle.dictionary.service.QeaaDataService;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.List;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

class QeaaDataControllerTest {

    @Test
    void crud_flow() throws Exception {
        QeaaDataService service = mock(QeaaDataService.class);
        QeaaDataController controller = new QeaaDataController(service);
        MockMvc mvc = MockMvcBuilders.standaloneSetup(controller).build();

        when(service.create(any())).thenReturn(new QeaaDataDtos.Response(1L, "D1"));
        when(service.list()).thenReturn(List.of(new QeaaDataDtos.Response(1L, "D1")));
        when(service.update(eq(1L), any())).thenReturn(new QeaaDataDtos.Response(1L, "D2"));

        mvc.perform(post("/api/v1/dictionary/qeaa/data")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"name\":\"D1\"}"))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.name").value("D1"));

        mvc.perform(get("/api/v1/dictionary/qeaa/data"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].name").value("D1"));

        mvc.perform(put("/api/v1/dictionary/qeaa/data/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"name\":\"D2\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("D2"));

        mvc.perform(delete("/api/v1/dictionary/qeaa/data/1"))
                .andExpect(status().isNoContent());

        verify(service).delete(1L);
    }
}
