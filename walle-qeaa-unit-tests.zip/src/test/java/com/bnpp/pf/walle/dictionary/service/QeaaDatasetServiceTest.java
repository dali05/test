package com.bnpp.pf.walle.dictionary.service;

import com.bnpp.pf.walle.dictionary.dto.QeaaDatasetDtos;
import com.bnpp.pf.walle.dictionary.entity.QeaaDataEntity;
import com.bnpp.pf.walle.dictionary.entity.QeaaDatasetEntity;
import com.bnpp.pf.walle.dictionary.entity.QeaaTypeEntity;
import com.bnpp.pf.walle.dictionary.exception.NotFoundException;
import com.bnpp.pf.walle.dictionary.repository.QeaaDatasetRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class QeaaDatasetServiceTest {

    @Mock QeaaDatasetRepository repo;
    @Mock QeaaTypeService typeService;
    @Mock QeaaDataService dataService;

    @InjectMocks QeaaDatasetService service;

    @Test
    void create_requires_type_and_data_and_returns_dto() {
        QeaaTypeEntity type = new QeaaTypeEntity(); type.setName("T"); setId(type, 1L);
        QeaaDataEntity data = new QeaaDataEntity(); data.setName("D"); setId(data, 2L);
        when(typeService.getEntity(1L)).thenReturn(type);
        when(dataService.getEntity(2L)).thenReturn(data);

        when(repo.save(any())).thenAnswer(inv -> {
            QeaaDatasetEntity e = inv.getArgument(0);
            setId(e, 9L);
            return e;
        });

        var out = service.create(new QeaaDatasetDtos.CreateOrUpdateRequest("DS", 1L, 2L));

        assertEquals(9L, out.id());
        assertEquals("DS", out.name());
        assertEquals(1L, out.typeId());
        assertEquals("T", out.typeName());
        assertEquals(2L, out.dataId());
        assertEquals("D", out.dataName());
    }

    @Test
    void create_propagates_not_found_from_dependencies() {
        when(typeService.getEntity(1L)).thenThrow(new NotFoundException("QEAAType not found: 1"));
        assertThrows(NotFoundException.class,
                () -> service.create(new QeaaDatasetDtos.CreateOrUpdateRequest("DS", 1L, 2L)));
        verifyNoInteractions(repo);
    }

    @Test
    void list_maps_entities() {
        QeaaTypeEntity type = new QeaaTypeEntity(); type.setName("T"); setId(type, 1L);
        QeaaDataEntity data = new QeaaDataEntity(); data.setName("D"); setId(data, 2L);

        QeaaDatasetEntity ds = new QeaaDatasetEntity();
        setId(ds, 3L);
        ds.setName("DS");
        ds.setType(type);
        ds.setData(data);

        when(repo.findAll()).thenReturn(List.of(ds));

        var out = service.list();
        assertEquals(1, out.size());
        assertEquals("DS", out.get(0).name());
        assertEquals("T", out.get(0).typeName());
        assertEquals("D", out.get(0).dataName());
    }

    @Test
    void update_updates_fields() {
        QeaaTypeEntity type = new QeaaTypeEntity(); type.setName("T2"); setId(type, 10L);
        QeaaDataEntity data = new QeaaDataEntity(); data.setName("D2"); setId(data, 20L);
        when(typeService.getEntity(10L)).thenReturn(type);
        when(dataService.getEntity(20L)).thenReturn(data);

        QeaaDatasetEntity existing = new QeaaDatasetEntity();
        setId(existing, 7L);
        existing.setName("OLD");

        when(repo.findById(7L)).thenReturn(Optional.of(existing));

        var out = service.update(7L, new QeaaDatasetDtos.CreateOrUpdateRequest("NEW", 10L, 20L));

        assertEquals(7L, out.id());
        assertEquals("NEW", out.name());
        assertEquals("T2", out.typeName());
        assertEquals("D2", out.dataName());
        assertEquals("NEW", existing.getName());
        assertSame(type, existing.getType());
        assertSame(data, existing.getData());
    }

    @Test
    void update_throws_when_missing_dataset() {
        when(repo.findById(7L)).thenReturn(Optional.empty());
        assertThrows(NotFoundException.class,
                () -> service.update(7L, new QeaaDatasetDtos.CreateOrUpdateRequest("NEW", 1L, 2L)));
        verifyNoInteractions(typeService);
        verifyNoInteractions(dataService);
    }

    @Test
    void delete_throws_when_missing() {
        when(repo.existsById(5L)).thenReturn(false);
        assertThrows(NotFoundException.class, () -> service.delete(5L));
    }

    @Test
    void delete_deletes_when_exists() {
        when(repo.existsById(5L)).thenReturn(true);
        service.delete(5L);
        verify(repo).deleteById(5L);
    }

    private static void setId(Object obj, Long id) {
        try {
            var f = obj.getClass().getDeclaredField("id");
            f.setAccessible(true);
            f.set(obj, id);
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }
}
