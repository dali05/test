package com.bnpp.pf.walle.dictionary.controller;

import com.bnpp.pf.walle.dictionary.dto.QeaaDatasetDtos;
import com.bnpp.pf.walle.dictionary.service.QeaaDatasetService;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.List;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

class QeaaDatasetControllerTest {

    @Test
    void crud_flow() throws Exception {
        QeaaDatasetService service = mock(QeaaDatasetService.class);
        QeaaDatasetController controller = new QeaaDatasetController(service);
        MockMvc mvc = MockMvcBuilders.standaloneSetup(controller).build();

        when(service.create(any())).thenReturn(new QeaaDatasetDtos.Response(1L, "DS1", 2L, "T", 3L, "D"));
        when(service.list()).thenReturn(List.of(new QeaaDatasetDtos.Response(1L, "DS1", 2L, "T", 3L, "D")));
        when(service.update(eq(1L), any())).thenReturn(new QeaaDatasetDtos.Response(1L, "DS2", 2L, "T", 3L, "D"));

        mvc.perform(post("/api/v1/dictionary/qeaa/datasets")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"name\":\"DS1\",\"typeId\":2,\"dataId\":3}"))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.name").value("DS1"))
                .andExpect(jsonPath("$.typeId").value(2))
                .andExpect(jsonPath("$.dataId").value(3));

        mvc.perform(get("/api/v1/dictionary/qeaa/datasets"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].name").value("DS1"));

        mvc.perform(put("/api/v1/dictionary/qeaa/datasets/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"name\":\"DS2\",\"typeId\":2,\"dataId\":3}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("DS2"));

        mvc.perform(delete("/api/v1/dictionary/qeaa/datasets/1"))
                .andExpect(status().isNoContent());

        verify(service).delete(1L);
    }
}
