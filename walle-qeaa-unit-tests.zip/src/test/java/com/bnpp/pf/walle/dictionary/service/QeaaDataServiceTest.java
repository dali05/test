package com.bnpp.pf.walle.dictionary.service;

import com.bnpp.pf.walle.dictionary.dto.QeaaDataDtos;
import com.bnpp.pf.walle.dictionary.entity.QeaaDataEntity;
import com.bnpp.pf.walle.dictionary.exception.NotFoundException;
import com.bnpp.pf.walle.dictionary.repository.QeaaDataRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class QeaaDataServiceTest {

    @Mock
    QeaaDataRepository repo;

    @InjectMocks
    QeaaDataService service;

    @Test
    void create_saves_and_returns_dto() {
        when(repo.save(any())).thenAnswer(inv -> {
            QeaaDataEntity e = inv.getArgument(0);
            var persisted = new QeaaDataEntity();
            persisted.setName(e.getName());
            setId(persisted, 11L);
            return persisted;
        });

        var dto = service.create(new QeaaDataDtos.CreateOrUpdateRequest("DATA_A"));
        assertEquals(11L, dto.id());
        assertEquals("DATA_A", dto.name());
    }

    @Test
    void list_maps_entities() {
        QeaaDataEntity e1 = new QeaaDataEntity(); e1.setName("D1"); setId(e1, 1L);
        QeaaDataEntity e2 = new QeaaDataEntity(); e2.setName("D2"); setId(e2, 2L);
        when(repo.findAll()).thenReturn(List.of(e1, e2));

        var out = service.list();
        assertEquals(2, out.size());
        assertEquals("D2", out.get(1).name());
    }

    @Test
    void update_updates_name() {
        QeaaDataEntity e = new QeaaDataEntity(); setId(e, 7L); e.setName("OLD");
        when(repo.findById(7L)).thenReturn(Optional.of(e));

        var out = service.update(7L, new QeaaDataDtos.CreateOrUpdateRequest("NEW"));
        assertEquals(7L, out.id());
        assertEquals("NEW", out.name());
        assertEquals("NEW", e.getName());
    }

    @Test
    void update_throws_when_missing() {
        when(repo.findById(99L)).thenReturn(Optional.empty());
        assertThrows(NotFoundException.class,
                () -> service.update(99L, new QeaaDataDtos.CreateOrUpdateRequest("X")));
    }

    @Test
    void delete_throws_when_missing() {
        when(repo.existsById(5L)).thenReturn(false);
        assertThrows(NotFoundException.class, () -> service.delete(5L));
    }

    @Test
    void delete_deletes_when_exists() {
        when(repo.existsById(5L)).thenReturn(true);
        service.delete(5L);
        verify(repo).deleteById(5L);
    }

    @Test
    void getEntity_returns_entity() {
        QeaaDataEntity e = new QeaaDataEntity(); setId(e, 3L);
        when(repo.findById(3L)).thenReturn(Optional.of(e));
        assertSame(e, service.getEntity(3L));
    }

    @Test
    void getEntity_throws_when_missing() {
        when(repo.findById(3L)).thenReturn(Optional.empty());
        assertThrows(NotFoundException.class, () -> service.getEntity(3L));
    }

    private static void setId(Object obj, Long id) {
        try {
            var f = obj.getClass().getDeclaredField("id");
            f.setAccessible(true);
            f.set(obj, id);
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }
}
