# Tests unitaires QEAA (JUnit 5 + Mockito + MockMvc)

Ces tests sont écrits pour les classes du ZIP `walle-dictionary-qeaa-full.zip` (IDs en Long).
Si tu es passé en UUID via BaseEntity, adapte les signatures (Long -> UUID) dans:
- DTOs
- controllers
- services
- tests

## Dépendances Maven
Assure-toi d'avoir:
- spring-boot-starter-test

## Lancer
mvn test
